package com.pwr.model;

import com.pwr.model.Technician;
import com.pwr.model.TechnicianDAO;

import java.sql.Connection;
import java.util.List;

public class TechnicianDAOImp implements TechnicianDAO {

	private Connection connection;

	/**
	 * 
	 * @param connection
	 */
	public TechnicianDAOImp(Connection connection) {
		// TODO - implement TechnicianDAOImp.TechnicianDAOImp
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param technician
	 */
	public void addTechnician(Technician technician) {
		// TODO - implement TechnicianDAOImp.addTechnician
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param updatedTechnician
	 */
	public void updateTechnician(Technician updatedTechnician) {
		// TODO - implement TechnicianDAOImp.updateTechnician
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param technicianId
	 */
	public Technician getTechnicianById(int technicianId) {
		// TODO - implement TechnicianDAOImp.getTechnicianById
		throw new UnsupportedOperationException();
	}

	public List<Technician> getAllTechnicians() {
		// TODO - implement TechnicianDAOImp.getAllTechnicians
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param technician
	 */
	public void deleteTechnician(Technician technician) {
		// TODO - implement TechnicianDAOImp.deleteTechnician
		throw new UnsupportedOperationException();
	}

}