package com.pwr.view;

import com.pwr.view.ITechnicianView;

public class TechnicianView implements ITechnicianView {

	/**
	 * 
	 * @param newAssignmentDetails
	 */
	public void displayNewAssignment(String newAssignmentDetails) {
		// TODO - implement TechnicianView.displayNewAssignment
		throw new UnsupportedOperationException();
	}

}