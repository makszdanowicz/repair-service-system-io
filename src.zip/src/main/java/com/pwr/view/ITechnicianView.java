package com.pwr.view;

public interface ITechnicianView {

	/**
	 * 
	 * @param newAssignmentDetails
	 */
	void displayNewAssignment(String newAssignmentDetails);

}